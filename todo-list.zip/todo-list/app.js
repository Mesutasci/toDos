/*
   1) Sayfadaki "ekle" butonuna basildiginda, input alaninda olan bilgi 
   javascript'e (memory) alinir. (OK)
   2) Alinan bu bilgiyi "ul" tagina "li" elemani olarak ekle. (OK)
*/ 

/* Bilgi girdisini alabilecegim elemana DOM vasitasi ile ulasiyorum */
let inputAlani = document.querySelector("#todo-entry");
let buttonDugmesi = document.querySelector("#todo-add-trigger");

buttonDugmesi.addEventListener("click", function(){
    let todoList = document.querySelector("#todo-list");
    let node = document.createElement("li");                  // Create a <li> node
    let textnode = document.createTextNode(inputAlani.value); // Create a text node
    node.appendChild(textnode);                               // Append the text to <li>
    todoList.appendChild(node); 

    /*girdi alanini temizle*/
    inputAlani.value = "";
});